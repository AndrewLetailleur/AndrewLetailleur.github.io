# Petz_Phaser3

Petz is a Virtual Interactive Pet game, with growth and training mechanics created within Phaser 3

Inspired from previous virtual pet games like Nintendo Dogs and Tamagotchi, this game is to make a simplistic version
using simple minigames to grow your pets gradually the more you play.

***

Please note that this is the first project we've all created with ES6 so some of the programming
may be a little all over the place due to module understanding. 
