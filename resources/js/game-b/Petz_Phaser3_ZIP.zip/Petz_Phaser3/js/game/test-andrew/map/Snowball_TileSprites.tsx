<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.5" name="Snowball_TileSprites" tilewidth="32" tileheight="32" tilecount="9" columns="3">
 <image source="TileSprites.png" width="96" height="96"/>
 <terraintypes>
  <terrain name="Land" tile="0"/>
  <terrain name="Sea" tile="4"/>
  <terrain name="Wall" tile="8"/>
 </terraintypes>
 <tile id="0" terrain="0,0,0,0"/>
 <tile id="1" terrain="0,0,0,0"/>
 <tile id="2" terrain="0,0,0,0"/>
 <tile id="3" terrain="0,0,0,0"/>
 <tile id="4" terrain="1,1,1,1"/>
 <tile id="5" terrain="1,1,1,1"/>
 <tile id="6" terrain="2,2,2,2"/>
 <tile id="7" terrain="2,2,2,2"/>
 <tile id="8" terrain="2,2,2,2"/>
</tileset>
